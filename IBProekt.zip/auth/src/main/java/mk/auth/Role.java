package mk.auth;

public enum Role {
    USER,
    ADMIN,
    MANAGER
}