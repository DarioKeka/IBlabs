package mk.auth;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

    private final UserRepository users;
    private final SessionRepository sessions;
    private final EmailService emailService;

    public AuthService(UserRepository users, SessionRepository sessions, EmailService emailService) {
        this.users = users;
        this.sessions = sessions;
        this.emailService = emailService;
    }

    // --- РЕГИСТРАЦИЈА ---
    @Transactional
    public String register(String username, String email, String password) {
        if (users.findByUsername(username).isPresent()) return "Корисничкото име е зафатено";
        if (users.findByEmail(email).isPresent()) return "Е-маилот е веќе регистриран";

        String saltB64 = CryptoUtils.generateSaltBase64();
        byte[] salt = Base64.getDecoder().decode(saltB64);
        String hash = CryptoUtils.pbkdf2Hash(password, salt);

        UserEntity u = new UserEntity(username, email, hash, saltB64);
        u.role = Role.USER; // Почетна улога
        users.save(u);
        return null;
    }

    // --- ЛОГИН (ЧЕКОР 1) ---
    @Transactional
    public String loginStart(String username, String password) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return "Невалидни податоци";

        UserEntity u = ou.get();
        byte[] salt = Base64.getDecoder().decode(u.salt);
        String hash = CryptoUtils.pbkdf2Hash(password, salt);

        if (!hash.equals(u.passwordHash)) return "Невалидни податоци";

        // Генерирање 6-цифрен код
        String code = String.format("%06d", (int)(Math.random()*900000)+100000);
        u.twoFactorCode = code;
        u.twoFactorExpiry = Instant.now().plus(Duration.ofMinutes(5));
        users.save(u);

        // Испраќање код (Конзола симулација преку EmailService)
        emailService.sendTwoFactorCode(u.email, code);
        return "Се чека 2FA";
    }

    // --- ЛОГИН (ЧЕКОР 2 - ВЕРИФИКАЦИЈА) ---
    @Transactional
    public String verifyTwoFactor(String username, String code) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return null;

        UserEntity u = ou.get();
        if (u.twoFactorCode == null || u.twoFactorExpiry == null) return null;
        if (Instant.now().isAfter(u.twoFactorExpiry)) return null;
        if (!u.twoFactorCode.equals(code)) return null;

        // Успешна најава - креирај сесија
        String token = UUID.randomUUID().toString();
        sessions.save(new SessionEntity(token, username, Instant.now().plus(Duration.ofHours(24))));

        // Исчисти код
        u.twoFactorCode = null;
        u.twoFactorExpiry = null;
        users.save(u);

        return token;
    }

    public UserEntity getUserBySession(String token) {
        if (token == null) return null;
        Optional<SessionEntity> os = sessions.findById(token);
        if (os.isEmpty()) return null;

        SessionEntity s = os.get();
        if (Instant.now().isAfter(s.expiry)) {
            sessions.delete(s);
            return null;
        }
        return users.findByUsername(s.username).orElse(null);
    }

    public void logout(String token) {
        if (token != null) sessions.deleteById(token);
    }

    // --- МЕНАЏМЕНТ НА УЛОГИ ---

    @Transactional
    public void changeUserRole(String username, Role newRole) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isPresent()) {
            UserEntity u = ou.get();
            // Админот не смее сам себе да си ја смени улогата за да не се заклучи,
            // но за оваа проста програма ќе дозволиме промена.
            u.role = newRole;
            users.save(u);
        }
    }
}