package mk.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImprovedAuthApplication {
    public static void main(String[] args) {
        SpringApplication.run(ImprovedAuthApplication.class, args);
    }
}
