package mk.auth;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class AuthController {

    private final UserRepository users; // За листање во админ
    private final AuthService auth;

    public AuthController(AuthService auth, UserRepository users) {
        this.auth = auth;
        this.users = users;
    }

    // Помошен метод за читање колаче
    private String getTokenFromCookie(HttpServletRequest request) {
        if (request.getCookies() == null) return null;
        for (Cookie c : request.getCookies()) {
            if ("session".equals(c.getName())) return c.getValue();
        }
        return null;
    }

    @GetMapping("/")
    public String home(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        UserEntity user = auth.getUserBySession(token);

        model.addAttribute("user", user); // user може да биде null ако не е логиран
        return "home";
    }

    // --- РЕГИСТРАЦИЈА ---
    @GetMapping("/register")
    public String registerPage() { return "register"; }

    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String email, @RequestParam String password, Model model) {
        // Валидација на е-маил
        String emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$";
        if (!email.matches(emailPattern)) {
            model.addAttribute("error", "Е-маил мора да биде во формат user@domain.com");
            return "register";
        }
        // Валидација на лозинка (Min 8, Upper, Lower, Digit, Special)
        String passPattern = ".*(?=.{8,})(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).*";
        if (!password.matches(passPattern)) {
            model.addAttribute("error", "Лозинка: мин 8 карактери, 1 голема, 1 мала, 1 бројка, 1 специјален знак.");
            return "register";
        }

        String err = auth.register(username, email, password);
        if (err != null) {
            model.addAttribute("error", err);
            return "register";
        }
        return "redirect:/login";
    }

    // --- ЛОГИН ---
    @GetMapping("/login")
    public String loginPage() { return "login"; }

    @PostMapping("/login")
    public String loginStart(@RequestParam String username, @RequestParam String password, Model model) {
        String res = auth.loginStart(username, password);
        if (!"Се чека 2FA".equals(res)) {
            model.addAttribute("error", res);
            return "login";
        }
        model.addAttribute("username", username);
        return "verify-2fa";
    }

    @PostMapping("/verify-2fa")
    public String verify2fa(@RequestParam String username, @RequestParam String code, HttpServletResponse response, Model model) {
        String token = auth.verifyTwoFactor(username, code);
        if (token == null) {
            model.addAttribute("error", "Неточен код");
            model.addAttribute("username", username);
            return "verify-2fa";
        }
        Cookie cookie = new Cookie("session", token);
        cookie.setPath("/");
        response.addCookie(cookie);
        return "redirect:/";
    }

    // --- АДМИН ДЕЛ ---
    @GetMapping("/admin")
    public String adminPage(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        UserEntity user = auth.getUserBySession(token);

        // Проверка дали е Админ
        if (user == null || user.role != Role.ADMIN) {
            return "access-denied"; // Прикажува дека нема привилегии
        }

        // Листа на сите корисници за да може да им менува улоги
        List<UserEntity> allUsers = users.findAll();
        model.addAttribute("users", allUsers);
        model.addAttribute("currentUser", user);
        return "admin";
    }

    @PostMapping("/admin/set-role")
    public String setRole(HttpServletRequest request, @RequestParam String username, @RequestParam Role role) {
        String token = getTokenFromCookie(request);
        UserEntity admin = auth.getUserBySession(token);

        if (admin != null && admin.role == Role.ADMIN) {
            auth.changeUserRole(username, role);
        }
        return "redirect:/admin";
    }

    // --- МЕНАЏЕР ДЕЛ ---
    @GetMapping("/manager")
    public String managerPage(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        UserEntity user = auth.getUserBySession(token);

        if (user == null || user.role != Role.MANAGER) {
            return "access-denied";
        }
        model.addAttribute("user", user);
        return "manager";
    }

    // Излез од менаџерска страна -> Губење на улогата
    @PostMapping("/manager/exit")
    public String managerExit(HttpServletRequest request) {
        String token = getTokenFromCookie(request);
        UserEntity user = auth.getUserBySession(token);

        if (user != null && user.role == Role.MANAGER) {
            auth.changeUserRole(user.username, Role.USER); // Враќање во USER
        }
        return "redirect:/";
    }

    @PostMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        auth.logout(getTokenFromCookie(request));
        Cookie c = new Cookie("session", "");
        c.setMaxAge(0);
        c.setPath("/");
        response.addCookie(c);
        return "redirect:/";
    }
}