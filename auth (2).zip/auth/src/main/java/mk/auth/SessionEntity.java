package mk.auth;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "sessions")
public class SessionEntity {
    @Id
    public String token;

    public String username;

    public Instant expiry;

    public SessionEntity() {}

    public SessionEntity(String token, String username, Instant expiry) {
        this.token = token;
        this.username = username;
        this.expiry = expiry;
    }
}


