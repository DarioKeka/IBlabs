package mk.auth;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Base64;

@Configuration
public class AdminBootstrap {

    @Bean
    CommandLineRunner createAdmin(UserRepository users) {
        return args -> {

            if (users.findByUsername("admin").isEmpty()) {

                String salt = CryptoUtils.generateSaltBase64();
                byte[] saltBytes = Base64.getDecoder().decode(salt);
                String hash = CryptoUtils.pbkdf2Hash("Admin123!", saltBytes);

                UserEntity admin = new UserEntity(
                        "admin",
                        "admin@system.com",
                        hash,
                        salt
                );

                admin.role = Role.ADMIN;

                users.save(admin);

                System.out.println("✅ ADMIN креиран: admin / Admin123!");
            }
        };
    }
}
