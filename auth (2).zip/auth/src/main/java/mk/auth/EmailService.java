package mk.auth;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender sender;

    public EmailService(JavaMailSender sender) {
        this.sender = sender;
    }

    public void sendTwoFactorCode(String to, String code) {
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setTo(to);
            msg.setSubject("Your 2FA code");
            msg.setText("Your verification code is: " + code);
            sender.send(msg);
            System.out.println("[EmailService] Sent 2FA code to: " + to);
        } catch (Exception ex) {
            System.out.println("[EmailService - fallback] To: " + to + " Code: " + code);
        }
    }
}
