package mk.auth;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

@Controller
public class AuthController {

    private final UserRepository users;

    private final AuthService auth;


    public AuthController(AuthService auth, UserRepository users) {

        this.auth = auth;
        this.users = users;
    }

    private String getTokenFromCookie(HttpServletRequest request) {
        if (request.getCookies() == null) return null;
        for (Cookie c : request.getCookies()) {
            if ("session".equals(c.getName())) return c.getValue();
        }
        return null;
    }

    @GetMapping("/")
    public String home(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);

        String user = auth.getUserBySession(token);
        Role role = auth.getEffectiveRoleBySession(token);

        model.addAttribute("user", user);
        model.addAttribute("role", role);
        return "home";
    }

    @GetMapping("/register")
    public String registerPage() { return "register"; }

    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String email, @RequestParam String password, Model model) {
        String emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$";
        if (!email.matches(emailPattern)) {
            model.addAttribute("error", "Е-маил мора да биде во формат user@domain.com");
            return "register";
        }
        String passPattern = ".*(?=.{8,})(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).*";
        if (!password.matches(passPattern)) {
            model.addAttribute("error", "Лозинка мора да има >=8 карактери, 1 голема буква, 1 цифра и 1 специјален карактер");
            return "register";
        }
        String err = auth.register(username, email, password);
        if (err != null) {
            model.addAttribute("error", err);
            return "register";
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage() { return "login"; }

    @PostMapping("/login")
    public String loginStart(@RequestParam String username, @RequestParam String password, Model model) {
        String res = auth.loginStart(username, password);
        if ("INVALID".equals(res)) {
            model.addAttribute("error", "Неточни креденцијали");
            return "login";
        }
        model.addAttribute("username", username);
        return "verify-2fa";
    }

    @PostMapping("/verify-2fa")
    public String verify2fa(@RequestParam String username, @RequestParam String code, HttpServletResponse response, Model model) {
        String token = auth.verifyTwoFactor(username, code);
        if (token == null) {
            model.addAttribute("error", "Неточен или истечен код");
            model.addAttribute("username", username);
            return "verify-2fa";
        }
        Cookie cookie = new Cookie("session", token);
        cookie.setPath("/");
        response.addCookie(cookie);
        return "redirect:/";
    }

    @GetMapping("/admin")
    public String adminPage(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        Role role = auth.getEffectiveRoleBySession(token);

        if (role != Role.ADMIN) {
            return "access-denied";
        }

        return "admin";
    }

    @GetMapping("/user")
    public String userPage(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        String username = auth.getUserBySession(token);
        if (username == null) return "redirect:/login";

        Optional<UserEntity> ou = users.findByUsername(username); // Inject UserRepository
        if (ou.isEmpty()) return "redirect:/login";
        UserEntity u = ou.get();

        long remainingMinutes = 0;
        if (u.temporaryRole != null && u.temporaryRoleExpiry != null) {
            Instant now = Instant.now();
            if (now.isBefore(u.temporaryRoleExpiry)) {
                remainingMinutes = Duration.between(now, u.temporaryRoleExpiry).toMinutes();
            } else {

                u.temporaryRole = null;
                u.temporaryRoleExpiry = null;
                users.save(u);
            }
        }

        model.addAttribute("remainingMinutes", remainingMinutes);
        return "user";
    }

    @GetMapping("/request-access")
    public String requestAccess(HttpServletRequest request) {
        String token = getTokenFromCookie(request);
        auth.requestTemporaryResourceAccess(token);
        return "redirect:/resource";
    }


    @GetMapping("/resource")
    public String resource(HttpServletRequest request) {
        String token = getTokenFromCookie(request);
        Role role = auth.getEffectiveRoleBySession(token);

        if (role != Role.RESOURCE_ACCESS && role != Role.ADMIN) {
            return "access-denied";
        }

        return "resource";
    }


    @PostMapping("/resource/exit")
    public String exitResource(HttpServletRequest request) {
        String token = getTokenFromCookie(request);
        auth.revokeTemporaryAccess(token);
        return "redirect:/";
    }





    @PostMapping("/user/grant-temp")
    public String grantTempAccess(@RequestParam String username) {
        auth.grantTemporaryRole(username, Role.USER, Duration.ofMinutes(5));
        return "redirect:/user";
    }



    @PostMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        String token = getTokenFromCookie(request);
        auth.logout(token);
        Cookie cookie = new Cookie("session", "");
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
        return "redirect:/";
    }
}
