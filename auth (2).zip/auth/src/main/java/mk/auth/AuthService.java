package mk.auth;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.Duration;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

    private final UserRepository users;
    private final SessionRepository sessions;
    private final EmailService emailService;

    public AuthService(UserRepository users, SessionRepository sessions, EmailService emailService) {
        this.users = users;
        this.sessions = sessions;
        this.emailService = emailService;
    }

    @Transactional
    public String register(String username, String email, String password) {
        if (users.findByUsername(username).isPresent()) return "Името е веќе искористено";
        if (users.findByEmail(email).isPresent()) return "Веќе регистриран е-маил";
        String saltB64 = CryptoUtils.generateSaltBase64();
        byte[] salt = Base64.getDecoder().decode(saltB64);
        String hash = CryptoUtils.pbkdf2Hash(password, salt);
        UserEntity u = new UserEntity(username, email, hash, saltB64);
        u.role = Role.USER;
        users.save(u);
        return null;
    }

    @Transactional
    public String loginStart(String username, String password) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return "Не валидни податоци";
        UserEntity u = ou.get();
        byte[] salt = Base64.getDecoder().decode(u.salt);
        String hash = CryptoUtils.pbkdf2Hash(password, salt);
        if (!hash.equals(u.passwordHash)) return "Не валидни податоци";
        String code = String.format("%06d", (int)(Math.random()*900000)+100000);
        u.twoFactorCode = code;
        u.twoFactorExpiry = Instant.now().plus(Duration.ofMinutes(5));
        users.save(u);
        emailService.sendTwoFactorCode(u.email, code);
        return "Се чека 2FA";
    }

    @Transactional
    public String verifyTwoFactor(String username, String code) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return null;
        UserEntity u = ou.get();
        if (u.twoFactorCode == null || u.twoFactorExpiry == null) return null;
        if (Instant.now().isAfter(u.twoFactorExpiry)) return null;
        if (!u.twoFactorCode.equals(code)) return null;
        String token = UUID.randomUUID().toString();
        sessions.save(new SessionEntity(token, username, Instant.now().plus(Duration.ofHours(24))));
        u.twoFactorCode = null;
        u.twoFactorExpiry = null;
        users.save(u);
        return token;
    }

    public String getUserBySession(String token) {
        if (token == null) return null;
        Optional<SessionEntity> os = sessions.findById(token);
        if (os.isEmpty()) return null;
        SessionEntity s = os.get();
        if (Instant.now().isAfter(s.expiry)) {
            sessions.delete(s);
            return null;
        }
        return s.username;
    }
    public Role getEffectiveRoleBySession(String token) {
        if (token == null) return null;
        Optional<SessionEntity> os = sessions.findById(token);
        if (os.isEmpty()) return null;

        SessionEntity s = os.get();
        if (Instant.now().isAfter(s.expiry)) {
            sessions.delete(s);
            return null;
        }

        Optional<UserEntity> ou = users.findByUsername(s.username);
        if (ou.isEmpty()) return null;

        UserEntity u = ou.get();

        // JIT улога
        if (u.temporaryRole != null && u.temporaryRoleExpiry != null) {
            if (Instant.now().isBefore(u.temporaryRoleExpiry)) {
                return u.temporaryRole;
            } else {
                u.temporaryRole = null;
                u.temporaryRoleExpiry = null;
                users.save(u);
            }
        }

        return u.role;
    }

    @Transactional
    public boolean requestTemporaryResourceAccess(String token) {
        if (token == null) return false;

        Optional<SessionEntity> os = sessions.findById(token);
        if (os.isEmpty()) return false;

        String username = os.get().username;
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return false;

        UserEntity u = ou.get();

        // ВАЖИ САМО ЗА USER
        if (u.role != Role.USER) return false;

        u.temporaryRole = Role.RESOURCE_ACCESS;
        u.temporaryRoleExpiry = Instant.now().plus(Duration.ofMinutes(5));
        users.save(u);

        return true;
    }

    @Transactional
    public void revokeTemporaryAccess(String token) {
        if (token == null) return;

        Optional<SessionEntity> os = sessions.findById(token);
        if (os.isEmpty()) return;

        Optional<UserEntity> ou = users.findByUsername(os.get().username);
        if (ou.isEmpty()) return;

        UserEntity u = ou.get();
        u.temporaryRole = null;
        u.temporaryRoleExpiry = null;
        users.save(u);
    }



    @Transactional
    public void removeTemporaryAccess(String username) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return;

        UserEntity u = ou.get();
        u.temporaryRole = null;
        u.temporaryRoleExpiry = null;
        users.save(u);
    }



    @Transactional
    public void grantTemporaryRole(String username, Role role, Duration duration) {
        Optional<UserEntity> ou = users.findByUsername(username);
        if (ou.isEmpty()) return;

        UserEntity u = ou.get();
        u.temporaryRole = role;
        u.temporaryRoleExpiry = Instant.now().plus(duration);
        users.save(u);
    }



    public void logout(String token) {
        if (token == null) return;
        sessions.deleteById(token);
    }
}
