package mk.auth;

import jakarta.persistence.*;
import java.time.Instant;


@Entity
@Table(name = "users")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(unique = true, nullable = false)
    public String username;

    @Column(unique = true, nullable = false)
    public String email;

    @Column(nullable = false)
    public String passwordHash;

    @Column(nullable = false)
    public String salt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    public Role role = Role.USER;

    public String twoFactorCode;
    public Instant twoFactorExpiry;

    public boolean twoFactorEnabled = true;

    @Enumerated(EnumType.STRING)
    public Role temporaryRole;

    public Instant temporaryRoleExpiry;

    public boolean tempResourceAccess;
    public Instant tempResourceExpiry;


    public UserEntity() {}




    public UserEntity(String username, String email, String passwordHash, String salt) {
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.salt = salt;
    }
}
