package mk.auth;
public enum Role {
    USER,
    ADMIN,
    RESOURCE_ACCESS
}

