Детальна документација за програмата (improved-auth)

Вклучува: регистрација, најава со 2FA, H2 in-memory, управување со сесии, одјава.
Каде се наоѓаат клучните методи:
- CryptoUtils.pbkdf2Hash
- AuthService.register
- AuthService.loginStart
- AuthService.verifyTwoFactor
- AuthService.getUserBySession
- AuthService.logout
- EmailService.sendTwoFactorCode (fallback печати во конзола ако SMTP не е конфигурирано)
