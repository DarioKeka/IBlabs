package mk.auth;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    private String getTokenFromCookie(HttpServletRequest request) {
        if (request.getCookies() == null) return null;
        for (Cookie c : request.getCookies()) {
            if ("session".equals(c.getName())) return c.getValue();
        }
        return null;
    }

    @GetMapping("/")
    public String home(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        String user = auth.getUserBySession(token);
        model.addAttribute("user", user);
        return "home";
    }

    @GetMapping("/register")
    public String registerPage() { return "register"; }

    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String email, @RequestParam String password, Model model) {
        String emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$";
        if (!email.matches(emailPattern)) {
            model.addAttribute("error", "Е-маил мора да биде во формат user@domain.com");
            return "register";
        }
        String passPattern = ".*(?=.{8,})(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).*";
        if (!password.matches(passPattern)) {
            model.addAttribute("error", "Лозинка мора да има >=8 карактери, 1 голема буква, 1 цифра и 1 специјален карактер");
            return "register";
        }
        String err = auth.register(username, email, password);
        if (err != null) {
            model.addAttribute("error", err);
            return "register";
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage() { return "login"; }

    @PostMapping("/login")
    public String loginStart(@RequestParam String username, @RequestParam String password, Model model) {
        String res = auth.loginStart(username, password);
        if ("INVALID".equals(res)) {
            model.addAttribute("error", "Неточни креденцијали");
            return "login";
        }
        model.addAttribute("username", username);
        return "verify-2fa";
    }

    @PostMapping("/verify-2fa")
    public String verify2fa(@RequestParam String username, @RequestParam String code, HttpServletResponse response, Model model) {
        String token = auth.verifyTwoFactor(username, code);
        if (token == null) {
            model.addAttribute("error", "Неточен или истечен код");
            model.addAttribute("username", username);
            return "verify-2fa";
        }
        Cookie cookie = new Cookie("session", token);
        cookie.setPath("/");
        response.addCookie(cookie);
        return "redirect:/";
    }

    @PostMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        String token = getTokenFromCookie(request);
        auth.logout(token);
        Cookie cookie = new Cookie("session", "");
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
        return "redirect:/";
    }
}
