package mk.auth;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    @GetMapping("/")
    public String home(HttpServletRequest request, Model model) {
        String token = getTokenFromCookie(request);
        String user = auth.getUserBySession(token);
        model.addAttribute("user", user);
        return "home";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String email, @RequestParam String password, Model model) {
        if (!auth.register(username, email, password)) {
            model.addAttribute("error", "Корисникот веќе постои!");
            return "register";
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpServletResponse response, Model model) {
        String token = auth.login(username, password);
        if (token == null) {
            model.addAttribute("error", "Неточни податоци.");
            return "login";
        }
        Cookie cookie = new Cookie("session", token);
        cookie.setPath("/");
        response.addCookie(cookie);
        return "redirect:/";
    }

    private String getTokenFromCookie(HttpServletRequest request) {
        if (request.getCookies() == null) return null;
        for (Cookie c : request.getCookies()) {
            if (c.getName().equals("session")) return c.getValue();
        }
        return null;
    }
}
