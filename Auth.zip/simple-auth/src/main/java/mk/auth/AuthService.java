package mk.auth;

import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

@Service
public class AuthService {
    static class User {
        final String username;
        final String email;
        final String passwordHash;
        final String salt;

        User(String username, String email, String passwordHash, String salt) {
            this.username = username;
            this.email = email;
            this.passwordHash = passwordHash;
            this.salt = salt;
        }
    }

    private final Map<String, User> users = new HashMap<>();
    private final Map<String, String> sessions = new HashMap<>();
    private final SecureRandom random = new SecureRandom();

    public boolean register(String username, String email, String password) {
        if (users.containsKey(username)) return false;
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        String saltB64 = Base64.getEncoder().encodeToString(salt);
        String hash = hash(password, salt);
        users.put(username, new User(username, email, hash, saltB64));
        return true;
    }

    public String login(String username, String password) {
        User u = users.get(username);
        if (u == null) return null;
        byte[] salt = Base64.getDecoder().decode(u.salt);
        if (!hash(password, salt).equals(u.passwordHash)) return null;
        String token = UUID.randomUUID().toString();
        sessions.put(token, username);
        return token;
    }

    public String getUserBySession(String token) {
        return sessions.get(token);
    }

    private String hash(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            return Base64.getEncoder().encodeToString(md.digest(password.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
